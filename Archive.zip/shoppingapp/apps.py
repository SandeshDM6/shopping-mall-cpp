from django.apps import AppConfig


class ShoppingappConfig(AppConfig):
    name = 'shoppingapp'
